﻿using System;
using System.Collections.Generic;

namespace HotelBookingSystem.Models
{
    public partial class RoomBooking
    {
        public int BookingId { get; set; }
        public string EmailAddress { get; set; } = null!;
        public DateTime BookingFrom { get; set; }
        public DateTime BookingTo { get; set; }
        public string RoomNumber { get; set; } = null!;
        public int RoomTypeId { get; set; }

        public virtual Room RoomNumberNavigation { get; set; } = null!;
        public virtual RoomType RoomType { get; set; } = null!;
    }
}
