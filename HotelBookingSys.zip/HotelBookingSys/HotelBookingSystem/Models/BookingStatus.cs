﻿using System;
using System.Collections.Generic;

namespace HotelBookingSystem.Models
{
    public partial class BookingStatus
    {
        public BookingStatus()
        {
            Rooms = new HashSet<Room>();
        }

        public int BookingStatusId { get; set; }
        public string Status { get; set; } = null!;

        public virtual ICollection<Room> Rooms { get; set; }
    }
}
