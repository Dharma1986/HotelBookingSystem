﻿using System;
using System.Collections.Generic;

namespace HotelBookingSystem.Models
{
    public partial class Room
    {
        public int RoomId { get; set; }
        public string RoomNumber { get; set; } = null!;
        public int BookingStatusId { get; set; }
        public int RoomTypeId { get; set; }

        public virtual BookingStatus BookingStatus { get; set; } = null!;
        public virtual RoomType RoomType { get; set; } = null!;
    }
}
