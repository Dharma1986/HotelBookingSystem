import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';

@Component({
    selector: 'app-addroom-component',
    templateUrl: './addroom.component.html'
})


export class AddRoomComponent {

    roomTypes: RoomType[] = []

    constructor(private formBuilder: FormBuilder, private http: HttpClient, @Inject('BASE_URL') private baseUrl: string) {
        http.get<RoomType[]>(baseUrl + 'api/RoomTypes').subscribe(result => {
            this.roomTypes = result;
        }, error => console.error(error));
    }    

    addRoomForm = this.formBuilder.group({
        roomnumber: new FormControl('', Validators.required),
        roomType: new FormControl('', Validators.required)
    });

    get f() {
        return this.addRoomForm.controls;
    }

    submit() {
        var formData: any = new FormData();
        formData.append('roomnumber', this.addRoomForm.get('roomnumber').value);
        formData.append('roomType', this.addRoomForm.get('roomType').value);
        this.http
            .post(this.baseUrl + 'api/Rooms', formData)
            .subscribe({
                next: (response) => console.log(response),
                error: (error) => console.log(error),
            });
       
        console.log(this.addRoomForm.value);
    }
}

interface RoomType {
    roomTypeId: number;
    roomTypeName: string;
}

