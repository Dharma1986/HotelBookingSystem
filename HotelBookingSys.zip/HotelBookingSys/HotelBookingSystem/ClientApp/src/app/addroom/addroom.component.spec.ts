import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddRoomComponent } from './addroom.component';

describe('AddRoomComponent', () => {
    let component: AddRoomComponent;
    let fixture: ComponentFixture<AddRoomComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
        declarations: [AddRoomComponent]
    })
    .compileComponents();
  }));

  beforeEach(() => {
      fixture = TestBed.createComponent(AddRoomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

});
