import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
    selector: 'app-roomlist',
    templateUrl: './roomlist.component.html'
})
export class RoomListComponent {
    public rooms: Room[] = [];

    constructor(http: HttpClient, private router: Router, @Inject('BASE_URL') baseUrl: string) {
        http.get<Room[]>(baseUrl + 'api/Rooms').subscribe(result => {
            this.rooms = result;
        }, error => console.error(error));
    }

    goToAddRoom($myParam: string = ''): void {
        const navigationDetails: string[] = ['/addroom'];
        if ($myParam.length) {
            navigationDetails.push($myParam);
        }
        this.router.navigate(navigationDetails);
    }
}

interface Room {
    roomId: number;
    roomNumber: string;
    roomType: RoomType;
    bookingStatus: BookingStatus;
    bookingStatusId: number;
    roomTypeId: number;
}

interface RoomType {
    roomTypeId: number;
    roomTypeName: string;
}

interface BookingStatus {
    bookingStatusId: number;
    status: string;
}
