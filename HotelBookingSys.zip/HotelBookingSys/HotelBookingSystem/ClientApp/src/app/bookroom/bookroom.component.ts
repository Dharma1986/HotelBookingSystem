import { Component, Inject} from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { Router } from '@angular/router';

@Component({
  selector: 'app-bookroom-component',
    templateUrl: './bookroom.component.html'
})



export class BookRoomComponent {
    roomTypes: RoomType[] = []
    emailaddress: string;
    bookingfrom: Date;
    bookingto: Date;
    constructor(private formBuilder: FormBuilder, private router: Router, private http: HttpClient, @Inject('BASE_URL') private baseUrl: string) {
        http.get<RoomType[]>(baseUrl + 'api/RoomTypes').subscribe(result => {
            this.roomTypes = result;
        }, error => console.error(error));
    }

    bookRoomForm = this.formBuilder.group({
        emailaddress: new FormControl('', Validators.required),
        roomType: new FormControl('', Validators.required)
    });

    FromDateChange(event: MatDatepickerInputEvent<Date>) {
        this.bookingfrom = event.value;        
    }

    ToDateChange(event: MatDatepickerInputEvent<Date>) {
        this.bookingto = event.value;
    }

    get f() {
        return this.bookRoomForm.controls;
    }

    submit()
    {

        var roomBooking: RoomBooking = {
            emailAddress: this.bookRoomForm.get('emailaddress').value,
            RoomTypeId: this.bookRoomForm.get('roomType').value,
            bookingFrom : this.bookingfrom,
            bookingTo: this.bookingto,
            roomNumber: null
        };
        this.http
            .post<RoomBooking>(this.baseUrl + 'api/RoomBookings', roomBooking).subscribe(data => {
                console.log(data)
                const navigationDetails: string[] = ['/bookroom'];                
                this.router.navigate(navigationDetails);
            }, error => {
                console.log(error)
            });

        

        console.log(this.bookRoomForm);
    }

}

interface RoomType {
    roomTypeId: number;
    roomTypeName: string;
}

interface RoomBooking {
    emailAddress: string;
    bookingFrom: Date; 
    bookingTo: Date;
    RoomTypeId: number;
    roomNumber: string;
}


