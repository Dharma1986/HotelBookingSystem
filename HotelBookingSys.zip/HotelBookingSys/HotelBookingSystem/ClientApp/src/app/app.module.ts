import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

import { AppComponent } from './app.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { RoomListComponent } from './roomlist/roomlist.component';
import { BookRoomComponent } from './bookroom/bookroom.component';
import { AddRoomComponent } from './addroom/addroom.component';

@NgModule({
    declarations: [
        AppComponent,
        NavMenuComponent,
        RoomListComponent,
        BookRoomComponent,
        AddRoomComponent
    ],
    imports: [
        BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
        HttpClientModule,
        FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatFormFieldModule,
        MatInputModule,
        RouterModule.forRoot([
            { path: 'roomlist', component: RoomListComponent },
            { path: 'bookroom', component: BookRoomComponent },
            { path: 'addroom', component: AddRoomComponent }
        ])
    ],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule { }
