﻿using HotelBookingSystem.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HotelBookingSystem.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class RoomController : ControllerBase
    {
        private readonly HotelBookingSystemContext _context;

        public RoomController(HotelBookingSystemContext context)
        {
            _context = context;
        }

        private static readonly string[] RoomNumber = new[]
        {
            "A1", "A2", "A3", "A4", "B1", "B2", "B3", "C1", "C2", "C3"
        };


        [HttpGet]
        public IEnumerable<Room> Get()
        {
            //var rng = new Random();
            //return Enumerable.Range(1, 5).Select(index => new Room
            //{
            //    BookingStatus = new BookingStatus(){ Status = "not booked" },
            //    RoomType = new RoomType() { RoomTypeName = "Single" },
            //    RoomNumber = "A12"
            //}).ToArray();
          
            return  _context.Rooms.ToArray();
        }
    }
}
