﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HotelBookingSystem.Models;

namespace HotelBookingSystem.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RoomsController : ControllerBase
    {
        private readonly HotelBookingSystemContext _context;

        public RoomsController(HotelBookingSystemContext context)
        {
            _context = context;
        }

        // GET: api/Rooms
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Room>>> GetRooms()
        {
            if (_context.Rooms == null)
            {
                return NotFound();
            }

            var rooms = _context.Rooms.Join(
                            _context.BookingStatuses,
                            rm => rm.BookingStatusId,
                            bks => bks.BookingStatusId,
                            (rm, bks) => new { rm, bks }
                        ).Join(
                            _context.RoomTypes,
                            room => room.rm.RoomTypeId,
                            rt => rt.RoomTypeId,
                            (room, rt) => new Room
                            {
                                RoomId = room.rm.RoomId,
                                RoomNumber = room.rm.RoomNumber,
                                RoomTypeId = room.rm.RoomTypeId,
                                BookingStatusId = room.rm.BookingStatusId,
                                BookingStatus = room.bks,
                                RoomType = rt
                            }
                        );

            return await rooms.ToArrayAsync();
        }

        // GET: api/Rooms/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Room>> GetRoom(int id)
        {
            if (_context.Rooms == null)
            {
                return NotFound();
            }
            var room = await _context.Rooms.FindAsync(id);

            if (room == null)
            {
                return NotFound();
            }

            return room;
        }

        // PUT: api/Rooms/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutRoom(string roomNumber, Room room)
        {
            _context.Entry(room).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RoomExists(roomNumber))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Rooms
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Room>> PostRoom([FromForm] string roomnumber, [FromForm] string roomtype)
        {
           
            try
            {
                var room = new Room()
                {
                    RoomNumber = roomnumber,
                    RoomTypeId = _context.RoomTypes.Where(s => s.RoomTypeName == roomtype).FirstOrDefault().RoomTypeId,
                    BookingStatusId = 2,
                };


                if(_context.Rooms.Any(p => p.RoomNumber == roomnumber))
                {
                    return Problem("Same Room Number already exist.");
                }

                _context.Rooms.Add(room);
                await _context.SaveChangesAsync();

                return Ok(room);
            }
            catch (Exception ex)
            {
                //Handle the exception.
                throw ex;
            }
        }

        // DELETE: api/Rooms/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRoom(int id)
        {
            if (_context.Rooms == null)
            {
                return NotFound();
            }
            var room = await _context.Rooms.FindAsync(id);
            if (room == null)
            {
                return NotFound();
            }

            _context.Rooms.Remove(room);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool RoomExists(string id)
        {
            return (_context.Rooms?.Any(e => e.RoomNumber == id)).GetValueOrDefault();
        }
    }
}
