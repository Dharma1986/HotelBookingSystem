﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HotelBookingSystem.Models;

namespace HotelBookingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoomBookingsController : ControllerBase
    {
        private readonly HotelBookingSystemContext _context;

        public RoomBookingsController(HotelBookingSystemContext context)
        {
            _context = context;
        }

        // GET: api/RoomBookings
        [HttpGet]
        public async Task<ActionResult<IEnumerable<RoomBooking>>> GetRoomBookings()
        {
            if (_context.RoomBookings == null)
            {
                return NotFound();
            }
            return await _context.RoomBookings.ToListAsync();
        }

        // GET: api/RoomBookings/5
        [HttpGet("{id}")]
        public async Task<ActionResult<RoomBooking>> GetRoomBooking(int id)
        {
            if (_context.RoomBookings == null)
            {
                return NotFound();
            }
            var roomBooking = await _context.RoomBookings.FindAsync(id);

            if (roomBooking == null)
            {
                return NotFound();
            }

            return roomBooking;
        }

        // PUT: api/RoomBookings/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutRoomBooking(int id, RoomBooking roomBooking)
        {
            if (id != roomBooking.BookingId)
            {
                return BadRequest();
            }

            _context.Entry(roomBooking).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RoomBookingExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/RoomBookings
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<RoomBooking>> PostRoomBooking(RoomBooking roomBooking)
        {
            try
            {
                //var notBookedRooms = (from rb in _context.RoomBookings
                //                      join rt in _context.RoomTypes on rb.RoomTypeId equals rt.RoomTypeId
                //                      join r in _context.Rooms on rb.RoomNumber equals r.RoomNumber
                //                      where r.BookingStatusId == 2   
                //                      select new Room
                //                      {
                //                          RoomId = r.RoomId,
                //                          RoomNumber = r.RoomNumber,
                //                          RoomTypeId = r.RoomTypeId,
                //                          BookingStatusId = r.BookingStatusId,
                //                          RoomType = rt
                //                      });

                var bookedRooms = _context.RoomBookings.Where(p => p.BookingFrom >= roomBooking.BookingFrom && p.BookingTo <= roomBooking.BookingTo
                 && p.RoomTypeId == roomBooking.RoomTypeId && !string.IsNullOrEmpty(p.RoomNumber)).ToList<RoomBooking>();
                var notBookedRooms = new List<Room>();
                notBookedRooms = bookedRooms.Count() > 0
                    ? _context.Rooms.Where(x => bookedRooms.All(y => y.RoomNumber != x.RoomNumber)).ToList()
                    : _context.Rooms.ToList();
                var roomBook = new RoomBooking();
                if (bookedRooms.Count() > 0)
                {
                    return Problem("Rooms not available on selected dates and room type.");
                }
                else
                {
                    roomBook = new RoomBooking()
                    {
                        EmailAddress = roomBooking.EmailAddress,
                        RoomTypeId = roomBooking.RoomTypeId,
                        BookingFrom = roomBooking.BookingFrom,
                        BookingTo = roomBooking.BookingTo,
                        RoomNumber = notBookedRooms.FirstOrDefault().RoomNumber
                    };                   

                    _context.RoomBookings.Add(roomBook);
                    await _context.SaveChangesAsync();
                }

                return Ok(roomBook);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        // DELETE: api/RoomBookings/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRoomBooking(int id)
        {
            if (_context.RoomBookings == null)
            {
                return NotFound();
            }
            var roomBooking = await _context.RoomBookings.FindAsync(id);
            if (roomBooking == null)
            {
                return NotFound();
            }

            _context.RoomBookings.Remove(roomBooking);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool RoomBookingExists(int id)
        {
            return (_context.RoomBookings?.Any(e => e.BookingId == id)).GetValueOrDefault();
        }

        private bool RoomExists(int id)
        {
            return (_context.Rooms?.Any(e => e.RoomId == id)).GetValueOrDefault();
        }
    }
}
